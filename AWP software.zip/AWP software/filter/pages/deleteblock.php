<?php
include_once("lib/config.php");
include_once("lib/db.php");

if (isset($_GET['blockid'])) {
	 $blockid = $_GET['blockid'];
} else {
    header('location: index.php');
}

$sqlprod = mysqli_query($engine_conx, "DELETE FROM forum_blocks WHERE block_id='$blockid' LIMIT 1"); 
header('location: index.php?success=true');
?>