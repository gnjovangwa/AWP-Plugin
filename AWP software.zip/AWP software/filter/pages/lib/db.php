<?php
 /**
 //--------------------------------------------------------------\\
	********* * mulaCorp ENGINE **********
 \\---------------------------------------------------------------//

/**
 *
 * @package	mula system
 * @author		Joseph mulagwanda
 * @version		Version 1.0
 * @created		March 2017
 * @email		mulagwanda99@gmail.com
 * @link		http://www.developict.com
 * @framework	mulaframework
 
  */
  
/**
*/
$engine_conx = mysqli_connect($config['db.host'], $config['db.username'], $config['db.password'], $config['db.name']);?>