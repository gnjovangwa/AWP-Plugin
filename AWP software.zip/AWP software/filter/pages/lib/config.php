<?php

$config['backuppath'] = "/backup/";



$config['db.host'] = "localhost";
$config['db.username'] = "root";
$config['db.password'] = "";
$config['db.name'] = "mulagwanda45_wakiliforums";




$config['db.port'] = "3306";
$config['db.charset'] = "utf8";
$config['exclude.dir'] = "backup,cgi-bin";
$config['exclude.file'] = ".bat,*.exe";
$config['autoarchive'] = true;
$config['timezone'] = "Africa/Nairobi";
$config['sessionname'] = "jmathius";
$config['sessionpassword'] = "mama";
$config['memory'] = "32";
$config['maxbackups'] = "200";