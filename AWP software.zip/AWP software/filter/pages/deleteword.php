<?php
include_once("lib/config.php");
include_once("lib/db.php");

if (isset($_GET['wordid'])) {
	 $wordid = $_GET['wordid'];
} else {
    header('location: index.php');
}

$sqlprod = mysqli_query($engine_conx, "DELETE FROM forum_filters WHERE filter_id='$wordid' LIMIT 1"); 
header('location: allwords.php?success=true');
?>