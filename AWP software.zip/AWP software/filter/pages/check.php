<?php
include_once("lib/config.php");
include_once("lib/db.php");

$strSQL = "SELECT filter_word FROM forum_filters ORDER BY filter_id DESC";
$objQuery = mysqli_query($engine_conx, $strSQL) or die ("Error Query [".$strSQL."]");

$mydata = array();
while ($row = $objQuery->fetch_assoc()) {
    $mydata[] = $row['filter_word'];
}
$json = json_encode($mydata);
$string = "'".implode("','",$mydata)."'";

function match($needles, $haystack)
{
    foreach($needles as $needle){
        if (strpos($haystack, $needle) !== false) {
            return true;
        }
    }
    return false;
}

$haystack = 'mamab sfklfjdfkl gsdgjksdkgh sdlkfjhgdsfj ghjsdkskg h bweg';
if(match($mydata, $haystack)){
   echo "Tusi lipo.";
} else {
    echo "Hakuna tusi.";
}

echo '<br/><br />';
	
	
$sim = similar_text('senge', 'kma', $perc);
echo "similarity: ($perc %)\n";